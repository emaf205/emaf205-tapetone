EMAF205 TAPETONE PUBLIC v1.0.0

Static public web app with footer links and separate SEO guide pages.
Audio processing stays client-side.

Links:
FREE AUDIO APPS: http://emaf205.com/audio
PREMIUM COLLECTION: http://emaf205.com/audio_pro
