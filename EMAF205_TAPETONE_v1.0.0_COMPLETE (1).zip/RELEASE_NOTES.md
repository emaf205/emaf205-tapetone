# EMAF205 TAPETONE v1.0.0

Included builds:

- **Premium** — tool-only, no user-facing links, local/online/PWA-ready.
- **Public** — same audio engine plus footer links and separate SEO guide pages.
- **GitHub Repository Package** — English README, screenshots, source, PWA assets, guide pages and test report.

Core workflow:

**Upload → Mode / Age → Process → Original / FX → Download WAV**

Audio processing is browser-side and does not require a paid audio API.
