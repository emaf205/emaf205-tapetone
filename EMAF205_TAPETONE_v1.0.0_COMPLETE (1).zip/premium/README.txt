EMAF205 TAPETONE PREMIUM v1.0.0

Standalone static audio web app.
- No external links
- No account
- No backend
- Browser-side audio processing
- WAV / MP3 input
- WAV 24-bit output
- PWA-ready over HTTPS or localhost

For simple local use, open index.html. If your browser blocks local PWA/service-worker features, run a local static server.
